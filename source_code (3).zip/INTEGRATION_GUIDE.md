# Complete Integration Guide: GitHub + Cloudflare + Supabase

This step-by-step guide will walk you through connecting all three platforms for your HOSTALL project. Follow these instructions after creating your GitHub account.

## Step 1: Create and Set Up GitHub Repository

1. Log in to your GitHub account at [github.com](https://github.com)
2. Click the "+" icon in the top-right corner and select "New repository"
3. Configure your repository:
   - Name: `hostall` (or your preferred name)
   - Description: "HOSTALL - Hostel Management Platform"
   - Visibility: Private (recommended for production code)
   - Initialize with README: ✓ Check this option
4. Click "Create repository"

## Step 2: Upload Your Code to GitHub

### Option A: Using GitHub Web Interface (Beginner)

1. In your repository, click "Add file" → "Upload files"
2. Drag and drop all your project files or use the file selector
3. Add a commit message: "Initial commit: HOSTALL project files"
4. Click "Commit changes"

### Option B: Using Git Command Line (Recommended)

1. Install Git on your computer if not already installed
2. Open Terminal/Command Prompt and navigate to your project folder:
   ```bash
   cd path/to/your/hostall/project
   ```
3. Initialize Git and connect to your repository:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: HOSTALL project files"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/hostall.git
   git push -u origin main
   ```
   (Replace `YOUR_USERNAME` with your actual GitHub username)

## Step 3: Set Up GitHub Secrets for Integrations

1. Go to your repository on GitHub
2. Click "Settings" → "Secrets and variables" → "Actions"
3. Add the following secrets by clicking "New repository secret" for each:

### Cloudflare Secrets:
   - Name: `CLOUDFLARE_API_TOKEN`
   - Value: *Your Cloudflare API token* (Get from Cloudflare Dashboard → My Profile → API Tokens)

   - Name: `CLOUDFLARE_ACCOUNT_ID`
   - Value: *Your Cloudflare account ID* (Find in Cloudflare Dashboard URL or Overview page)

### Supabase Secrets:
   - Name: `SUPABASE_URL`
   - Value: *Your Supabase project URL* (Get from Supabase Dashboard → Project Settings → API)

   - Name: `SUPABASE_ANON_KEY`
   - Value: *Your Supabase anonymous key* (Get from Supabase Dashboard → Project Settings → API)

   - Name: `SUPABASE_SERVICE_ROLE_KEY`
   - Value: *Your Supabase service role key* (Get from Supabase Dashboard → Project Settings → API)

## Step 4: Set Up Cloudflare Pages

1. Log in to your Cloudflare dashboard at [dash.cloudflare.com](https://dash.cloudflare.com)
2. In the sidebar, click "Pages"
3. Click "Create a project" → "Connect to Git"
4. Select "Connect GitHub" and authorize Cloudflare
5. Select your "hostall" repository from the list
6. Configure your build settings:
   - Project name: `hostall`
   - Production branch: `main`
   - Framework preset: None
   - Build command: *Leave empty*
   - Build output directory: `.` (just a dot)
7. Click "Save and Deploy" to start your first deployment

## Step 5: Connect Your Custom Domain

1. After your first deployment completes, go to your Pages project
2. Click "Custom domains" → "Set up a custom domain"
3. Enter your domain name (that you already have in Cloudflare)
4. Choose subdomain if desired (e.g., `www` or `app`)
5. Follow the verification steps (should be automatic since domain is in Cloudflare)
6. Select HTTPS setting: "Strict" (recommended)
7. Click "Continue" and wait for DNS propagation (usually quick for Cloudflare domains)

## Step 6: Configure Supabase Project for Your Domain

1. Log in to your Supabase dashboard at [app.supabase.io](https://app.supabase.io)
2. Select your project for HOSTALL
3. Go to "Authentication" → "URL Configuration"
4. Add your custom domain or Cloudflare Pages URL to the allowed list
5. Save changes

## Step 7: Connect Your Frontend Code to Supabase

1. Open your project's main JavaScript file (`app.js`)
2. Find or add the Supabase initialization code:
   ```javascript
   const supabaseUrl = 'https://YOUR_PROJECT_ID.supabase.co';
   const supabaseKey = 'YOUR_ANON_KEY';
   const supabase = supabase.createClient(supabaseUrl, supabaseKey);
   ```
3. Replace placeholders with your actual Supabase project URL and anon key
4. Save the file and push changes to GitHub:
   ```bash
   git add app.js
   git commit -m "Update Supabase connection details"
   git push
   ```

## Step 8: Set Up GitHub Actions for Automated Deployments

1. Create a `.github/workflows` directory in your repository:
   ```bash
   mkdir -p .github/workflows
   ```

2. Create a deployment workflow file at `.github/workflows/deploy.yml`:
   ```yaml
   name: Deploy to Cloudflare Pages

   on:
     push:
       branches: [main]
     workflow_dispatch:

   jobs:
     deploy:
       runs-on: ubuntu-latest
       steps:
         - uses: actions/checkout@v3
         
         - name: Deploy to Cloudflare Pages
           uses: cloudflare/wrangler-action@v3
           with:
             apiToken: ${{ secrets.CLOUDFLARE_API_TOKEN }}
             accountId: ${{ secrets.CLOUDFLARE_ACCOUNT_ID }}
             command: pages deploy . --project-name=hostall
             
         - name: Update Supabase data after deployment
           run: |
             curl -X POST "${{ secrets.SUPABASE_URL }}/functions/v1/sync-deployment" \
              -H "Authorization: Bearer ${{ secrets.SUPABASE_SERVICE_ROLE_KEY }}" \
              -H "Content-Type: application/json" \
              -d '{"deployment":"production","commit":"${{ github.sha }}"}'
   ```

3. Commit and push this file:
   ```bash
   git add .github/workflows/deploy.yml
   git commit -m "Add GitHub Actions deployment workflow"
   git push
   ```

## Step 9: Create Supabase Tables (If Not Already Done)

1. Go to your Supabase Dashboard → "Table Editor"
2. Create `hostels` table with columns matching your data structure:
   - `name`: text
   - `gender`: text
   - `location`: text
   - `details`: text
   - `map`: text
   - `phone`: text
   - `whatsapp`: text
   - `img`: text
   - `facilities`: JSON array
   - `other_facilities`: text
   - `created_at`: timestamp with timezone (default: `now()`)
   - `updated_at`: timestamp with timezone (default: `now()`)

3. Create `admins` table with columns:
   - `user_email`: text (primary key)
   - `password_hash`: text
   - `role`: text
   - `hostel_id`: text
   - `approved`: boolean
   - `created_at`: timestamp with timezone (default: `now()`)
   - Add 2FA columns:
     - `two_factor_secret`: text
     - `two_factor_enabled`: boolean (default: false)

## Step 10: Set Up Cloudflare Environment Variables

1. In Cloudflare Pages, go to your project settings
2. Click "Environment variables"
3. Add these variables for production environment:
   - `SUPABASE_URL`: Your Supabase project URL
   - `SUPABASE_ANON_KEY`: Your public Supabase API key
   - `GOOGLE_ANALYTICS_ID`: G-0NNWGNQE5Q
4. Click "Save" to apply these variables

## Step 11: Test Your Integration

1. Make a small change to your code (e.g., update README.md)
2. Commit and push the change to GitHub:
   ```bash
   git add README.md
   git commit -m "Test integration deployment"
   git push
   ```
3. Go to GitHub repository → "Actions" tab to watch the deployment workflow
4. Once complete, visit your Cloudflare Pages URL or custom domain
5. Check that your site is live and connected to Supabase

## Step 12: Set Up Monitoring and Analytics

1. In Cloudflare, go to "Analytics" → "Web Analytics"
2. Add your website for monitoring
3. Set up alerts for performance or security issues
4. If using Google Analytics, verify it's receiving data from your site

## Common Issues and Solutions

### Deployment Failures:
- Check GitHub Actions logs for specific error messages
- Verify API tokens have correct permissions
- Ensure repository structure is correct for deployment

### Supabase Connection Issues:
- Check CORS settings in Supabase
- Verify environment variables are correctly set
- Check browser console for connection errors

### Custom Domain Issues:
- Verify DNS settings are correct
- Ensure SSL certificate is properly provisioned
- Allow 24-48 hours for DNS propagation

## Important Security Notes

- Keep your `SUPABASE_SERVICE_ROLE_KEY` secure and only use in trusted environments
- Never expose sensitive API keys in client-side code
- Set up Row-Level Security (RLS) in Supabase for data protection
- Use environment-specific variables for development and production

## Next Steps

1. **Set up 2FA**: Implement the two-factor authentication system
2. **Create Admin Interface**: Finalize the admin dashboard
3. **Optimize Performance**: Configure caching and compression
4. **Set up Monitoring**: Implement error tracking and performance monitoring

Congratulations! Your HOSTALL project is now fully integrated with GitHub, Cloudflare, and Supabase!