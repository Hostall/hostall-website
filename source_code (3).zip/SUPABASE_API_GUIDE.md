# Getting Supabase API Keys for GitHub Actions

This guide explains how to get the necessary Supabase API keys needed to connect your HOSTALL project with Supabase through GitHub Actions.

## Keys You Need

You'll need three pieces of information from Supabase:

1. **Project URL** - The URL of your Supabase project
2. **Anon (Public) Key** - For client-side operations
3. **Service Role Key** - For server-side operations (GitHub Actions)

## Step 1: Access Your Supabase Project Settings

1. Log in to your [Supabase Dashboard](https://app.supabase.com)
2. Select your existing HOSTALL project or create a new one
3. In the left sidebar, click **"Project Settings"**

## Step 2: Get Project URL and API Keys

1. In Project Settings, click **"API"** in the sidebar
2. In the "Project URL" section, copy your project URL
   - It should look like: `https://xyzabcdef.supabase.co`
3. In the "Project API Keys" section:
   - Copy the **"anon public"** key (labeled as "anon" or "public")
   - Copy the **"service_role"** key (labeled as "service_role" or "secret")

## Step 3: Add Keys as GitHub Secrets

1. Go to your HOSTALL GitHub repository
2. Click **"Settings"** → **"Secrets and variables"** → **"Actions"**
3. Add the following secrets:

   a. Add a new repository secret:
      - Name: `SUPABASE_URL`
      - Value: Your Supabase project URL
      - Click "Add secret"

   b. Add another repository secret:
      - Name: `SUPABASE_ANON_KEY`
      - Value: Your anon public key
      - Click "Add secret"

   c. Add a final repository secret:
      - Name: `SUPABASE_SERVICE_ROLE_KEY`
      - Value: Your service_role key
      - Click "Add secret"

## Step 4: Verify Connection in Your Project

Add this code to your project to verify the connection (for temporary testing only):

```javascript
// Import Supabase client
import { createClient } from '@supabase/supabase-js'

// Initialize the Supabase client
const supabaseUrl = 'YOUR_SUPABASE_URL'
const supabaseAnonKey = 'YOUR_ANON_KEY'
const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Test connection
async function testConnection() {
  const { data, error } = await supabase.from('hostels').select('count(*)');
  if (error) {
    console.error('Connection failed:', error);
  } else {
    console.log('Connection successful!', data);
  }
}

testConnection();
```

Replace the placeholders with your actual values.

## Step 5: Configure Row-Level Security (RLS)

For security, ensure Row-Level Security is enabled on your Supabase tables:

1. Go to the **"Table Editor"** in your Supabase Dashboard
2. Select each table and click **"Authentication"** at the top
3. Enable RLS by toggling the switch
4. Create appropriate RLS policies:

### Example RLS Policy for Hostels Table

```sql
-- Allow anyone to read hostels data
CREATE POLICY "Enable read access for all users"
ON hostels
FOR SELECT
USING (true);

-- Allow only authenticated admins to insert, update, and delete
CREATE POLICY "Enable write access for admins only"
ON hostels
FOR ALL
USING (
  -- Check if user has admin role
  auth.uid() IN (
    SELECT user_id FROM admins WHERE role = 'admin' AND approved = true
  )
);
```

## Step 6: Set Up Environment-Specific Variables

For better security, consider environment-specific variables:

1. In your Cloudflare Pages project:
   - Go to your project settings
   - Click "Environment variables"
   - Add `SUPABASE_URL` and `SUPABASE_ANON_KEY` (NOT the service_role key)
   - Set these for each environment (production, preview, etc.)

2. Keep the GitHub secrets for deployment workflows

## Understanding the Different Keys

### Anon Key (Public)
- Used for client-side operations
- Has limited permissions based on RLS policies
- Can be exposed in frontend code
- Used for authenticated and anonymous user operations

### Service Role Key (Secret)
- Has admin-level access to your database
- Bypasses Row-Level Security
- **Never expose this in client-side code**
- Only use in secure environments like GitHub Actions
- For admin operations, database migrations, etc.

## Best Practices for API Key Security

1. **Never commit API keys** to your repository
2. **Never expose the service_role key** in browser-accessible code
3. **Rotate keys periodically** for better security
4. **Use environment variables** for different environments
5. **Implement proper RLS policies** on all tables
6. **Monitor API usage** in Supabase Dashboard
7. **Set up alerts** for unusual activity

## Troubleshooting Connection Issues

### Error: Invalid API Key
- Double-check that you've copied the key correctly
- Ensure there are no extra spaces or characters

### Error: CORS Issues
- Go to Supabase Authentication settings
- Add your domain to the list of allowed domains
- Include both development and production URLs

### Error: Unable to Connect
- Check if your Supabase project is active
- Verify your project URL is correct
- Check if your IP is restricted in Supabase settings

### Error: Permission Denied
- Check your Row-Level Security policies
- Verify the role/permissions of the connecting user
- Test with the SQL Editor in Supabase Dashboard

With these keys properly set up, GitHub Actions will be able to connect to your Supabase project for deployments, data migrations, and other automated operations.