# Complete Step-by-Step Setup Guide for Beginners

This guide walks you through setting up GitHub, Supabase, and Cloudflare for your HOSTALL project with no prior experience needed. We'll break each step into small, manageable tasks.

## Before You Start

You will need:
- A computer with internet access
- An email address
- About 2-3 hours to complete the entire setup
- No prior coding experience required

## Part 1: Setting Up GitHub

### Step 1: Create a GitHub Account

1. **Go to GitHub:**
   - Open your web browser
   - Go to [github.com](https://github.com)
   - Click "Sign up"

2. **Create Your Account:**
   - Enter your email address
   - Create a password
   - Choose a username
   - Solve the puzzle verification
   - Click "Create account"

3. **Verify Your Email:**
   - Check your email inbox
   - Open the verification email from GitHub
   - Click the verification link

### Step 2: Create a New Repository

1. **Log in to GitHub:**
   - Go to [github.com](https://github.com)
   - Enter your username/email and password

2. **Create a New Repository:**
   - Click the "+" icon in the top-right corner
   - Select "New repository"

3. **Configure Repository:**
   - Name: `hostall`
   - Description: "HOSTALL - Hostel Management Platform"
   - Choose "Private" repository
   - Check "Add a README file"
   - Click "Create repository"

### Step 3: Upload Initial Files

1. **Upload Files:**
   - Click "Add file" > "Upload files" in your repository
   - Drag and drop your website files or click to select them
   - Wait for files to upload

2. **Commit Changes:**
   - Scroll down to "Commit changes"
   - Add a message: "Initial upload of HOSTALL website"
   - Click "Commit changes"

## Part 2: Setting Up Supabase

### Step 1: Create a Supabase Account

1. **Go to Supabase:**
   - Open [supabase.com](https://supabase.com)
   - Click "Start your project" or "Sign up"

2. **Sign Up:**
   - You can sign up with GitHub (recommended)
   - Click "Continue with GitHub"
   - Authorize Supabase to access your GitHub account

### Step 2: Create a New Project

1. **Start New Project:**
   - Click "New Project"

2. **Set Up Project:**
   - Organization: Create a new organization (e.g., "HOSTALL Organization")
   - Name: "hostall"
   - Database Password: Create a strong password (WRITE THIS DOWN!)
   - Region: Choose closest to your users (e.g., "Mumbai (ap-south-1)" for Pakistan)
   - Pricing Plan: Free tier is fine to start
   - Click "Create new project"

3. **Wait for Setup:**
   - This will take 1-2 minutes
   - You'll see a loading screen as your database is created

### Step 3: Create Database Tables

1. **Access SQL Editor:**
   - In the Supabase dashboard, click "SQL Editor" on the left

2. **Create Hostels Table:**
   - Click "New Query"
   - Copy and paste this code:

```sql
-- Create hostel table
CREATE TABLE hostels (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  gender TEXT NOT NULL,
  location TEXT NOT NULL,
  details TEXT,
  map TEXT,
  phone TEXT,
  whatsapp TEXT,
  img TEXT,
  facilities JSONB DEFAULT '[]'::jsonb,
  other_facilities TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

3. **Create Admins Table:**
   - Click "New Query" again
   - Copy and paste this code:

```sql
-- Create admins table
CREATE TABLE admins (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL,
  hostel_id TEXT,
  approved BOOLEAN DEFAULT FALSE,
  two_factor_secret TEXT,
  two_factor_enabled BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

4. **Run Each Query:**
   - Click "Run" for each query to create the tables

### Step 4: Get Supabase API Keys

1. **Go to API Settings:**
   - In the left sidebar, click on the gear icon (Settings)
   - Click "API" in the sidebar

2. **Copy Your Project URL:**
   - Find the URL under "Project URL"
   - Copy it to a secure text file

3. **Copy Your API Keys:**
   - Find the "Project API Keys" section
   - Copy the "anon" key to your secure text file
   - Copy the "service_role" key to your secure text file
   - Label each clearly!

## Part 3: Setting Up Cloudflare

### Step 1: Create a Cloudflare Account

1. **Go to Cloudflare:**
   - Open [cloudflare.com](https://cloudflare.com)
   - Click "Sign up" in the top-right corner

2. **Create Account:**
   - Enter your email address
   - Create a password
   - Click "Sign Up"

3. **Verify Your Email:**
   - Check your email
   - Open the verification message from Cloudflare
   - Click the verification link

### Step 2: Set Up Cloudflare Pages

1. **Access Pages:**
   - In the Cloudflare dashboard, click "Pages" in the sidebar

2. **Create a New Project:**
   - Click "Create a Project"
   - Select "Connect to Git"

3. **Connect to GitHub:**
   - Click "Connect GitHub"
   - Follow the prompts to authorize Cloudflare
   - Select your "hostall" repository

4. **Configure Build Settings:**
   - Project name: "hostall"
   - Production branch: "main"
   - Build settings: Leave empty (or use defaults)
   - Click "Save and Deploy"

### Step 3: Get Cloudflare API Token

1. **Go to API Tokens:**
   - Click your profile icon in the top-right
   - Select "My Profile"
   - Click "API Tokens" in the sidebar

2. **Create New Token:**
   - Click "Create Token"
   - Select "Edit Cloudflare Workers" template
   - Click "Use template"

3. **Configure Token:**
   - Name: "HOSTALL Deployment"
   - Permissions: Leave as default
   - Account Resources: Select your account
   - Zone Resources: Leave as "All zones"
   - TTL: Set to 1 year
   - Click "Continue to summary"
   - Review and click "Create Token"

4. **Copy Your Token:**
   - Copy the displayed token to your secure text file
   - Label it clearly!
   - Note: This will ONLY be shown once!

5. **Get Account ID:**
   - Go back to Cloudflare dashboard
   - Look at the URL in your browser - it contains your Account ID:
   - Format: `dash.cloudflare.com/[ACCOUNT_ID]/pages`
   - Copy this ID to your secure text file

## Part 4: Connecting Everything Together

### Step 1: Add GitHub Repository Secrets

1. **Go to GitHub Repository:**
   - Open your "hostall" repository on GitHub

2. **Access Secrets:**
   - Click "Settings" tab
   - Click "Secrets and variables" in the sidebar
   - Select "Actions"

3. **Add Each Secret:**
   - Click "New repository secret"
   - Add each of these (one at a time):

   | Name | Value from your text file |
   |------|---------------------------|
   | `SUPABASE_URL` | Your Project URL from Supabase |
   | `SUPABASE_ANON_KEY` | Your "anon" key from Supabase |
   | `SUPABASE_SERVICE_ROLE_KEY` | Your "service_role" key from Supabase |
   | `CLOUDFLARE_API_TOKEN` | Your API Token from Cloudflare |
   | `CLOUDFLARE_ACCOUNT_ID` | Your Account ID from Cloudflare |

### Step 2: Create GitHub Actions Workflow

1. **Create Workflow File:**
   - In your GitHub repo, click "Add file" > "Create new file"
   - Type this path as the filename: `.github/workflows/deploy.yml`

2. **Add Workflow Content:**
   - Copy and paste this code:

```yaml
name: Deploy to Cloudflare Pages

on:
  push:
    branches: [main]
  workflow_dispatch:

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Deploy to Cloudflare Pages
        uses: cloudflare/wrangler-action@v3
        with:
          apiToken: ${{ secrets.CLOUDFLARE_API_TOKEN }}
          accountId: ${{ secrets.CLOUDFLARE_ACCOUNT_ID }}
          command: pages deploy . --project-name=hostall
          
      - name: Notify completion
        run: echo "Deployment complete!"
```

3. **Commit Workflow File:**
   - Scroll down
   - Add a message: "Add deployment workflow"
   - Click "Commit new file"

### Step 3: Set Up Cloudflare Environment Variables

1. **Go to Cloudflare Pages:**
   - Open Cloudflare dashboard > Pages
   - Click on your "hostall" project

2. **Add Environment Variables:**
   - Click "Settings" tab
   - Scroll to "Environment variables"
   - Add these variables (one by one):

   | Variable | Value |
   |----------|-------|
   | SUPABASE_URL | Your Supabase project URL |
   | SUPABASE_ANON_KEY | Your Supabase anon key |

3. **Save Changes:**
   - Click "Save" after adding all variables

### Step 4: Update Website Code to Connect to Supabase

1. **Edit Your HTML File:**
   - In GitHub, find and click on your "index.html" file
   - Click the pencil icon to edit

2. **Add Supabase JavaScript:**
   - Find the `<head>` section
   - Add this code before the closing `</head>` tag:

```html
<!-- Supabase JavaScript Library -->
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>

<!-- Initialize Supabase -->
<script>
  const supabaseUrl = 'YOUR_SUPABASE_URL';
  const supabaseKey = 'YOUR_SUPABASE_ANON_KEY';
  const supabase = supabase.createClient(supabaseUrl, supabaseKey);
</script>
```

3. **Replace Placeholder Values:**
   - Replace `YOUR_SUPABASE_URL` with your actual Supabase URL
   - Replace `YOUR_SUPABASE_ANON_KEY` with your actual anon key

4. **Commit Changes:**
   - Scroll down
   - Add a commit message: "Add Supabase connection"
   - Click "Commit changes"

## Part 5: Testing Your Setup

### Step 1: Test Automatic Deployment

1. **Make a Small Change:**
   - Edit any file in your repository (README.md is good for testing)
   - Make a minor change
   - Commit the change

2. **Watch Deployment:**
   - Go to the "Actions" tab in your repository
   - You should see your workflow running
   - Wait for it to complete (green checkmark)

### Step 2: Check Your Live Website

1. **Find Your Cloudflare Pages URL:**
   - Go to Cloudflare dashboard > Pages
   - Click on your "hostall" project
   - Find the URL (format: https://hostall.pages.dev)

2. **Visit Your Website:**
   - Open the URL in your browser
   - Your website should be live!

### Step 3: Test Database Connection

1. **Try Basic Database Functionality:**
   - Log in to your admin panel (if set up)
   - Try adding a test hostel listing
   - Check if it appears on the website

## Troubleshooting Common Issues

### GitHub Issues:
- **Files not showing up?** Make sure you committed them properly.
- **Actions not running?** Check that your workflow file is in the correct location.

### Supabase Issues:
- **Can't connect to database?** Double-check your URL and API keys.
- **Tables not created?** Make sure your SQL queries ran successfully.

### Cloudflare Issues:
- **Deployment failed?** Check your API token permissions.
- **Website not updating?** Try a manual deployment from the Cloudflare dashboard.

### Connection Issues:
- **Website can't connect to database?** Check your environment variables.
- **Errors in browser console?** Look for CORS issues in Supabase settings.

## Next Steps

1. **Set up custom domain** in Cloudflare (if you have one)
2. **Add security features** like authentication
3. **Create a staging environment** for testing changes
4. **Set up regular backups** of your database

## Getting Help

If you get stuck:
- Check documentation for each service
- Look for error messages in GitHub Actions logs
- Search for solutions on Stack Overflow or GitHub forums
- Consider hiring a developer for complex issues

Congratulations! You've set up a complete web application with GitHub, Supabase, and Cloudflare! 🎉