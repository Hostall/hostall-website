import { serve } from "https://deno.land/std@0.208.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

interface ScheduledTaskRequest {
  task_type: string
  parameters?: any
}

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  }

  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseKey)

    const { task_type, parameters }: ScheduledTaskRequest = await req.json()

    console.log(`Running scheduled task: ${task_type}`)

    let result = {}

    switch (task_type) {
      case 'daily_backup':
        result = await performDailyBackup(supabase)
        break
        
      case 'cache_refresh':
        result = await refreshGlobalCache(supabase)
        break
        
      case 'security_audit':
        result = await performSecurityAudit(supabase)
        break
        
      case 'cleanup_old_data':
        result = await cleanupOldData(supabase)
        break
        
      case 'generate_reports':
        result = await generateDailyReports(supabase, parameters)
        break
        
      case 'monitor_performance':
        result = await monitorPerformance(supabase)
        break
        
      default:
        throw new Error(`Unknown task type: ${task_type}`)
    }

    // Log the task execution
    await supabase
      .from('security_events')
      .insert({
        event_type: 'scheduled_task_completed',
        details: {
          task_type,
          parameters,
          result,
          timestamp: new Date().toISOString()
        }
      })

    return new Response(
      JSON.stringify({
        success: true,
        task_type,
        result,
        timestamp: new Date().toISOString()
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    console.error('Scheduled task error:', error)
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    )
  }
})

async function performDailyBackup(supabase: any) {
  console.log('Performing daily backup...')
  
  try {
    // Call the backup function
    const { error } = await supabase.rpc('backup_critical_data')
    
    if (error) {
      throw error
    }
    
    // Clean up old backups
    await supabase.rpc('purge_old_backups')
    
    return {
      status: 'completed',
      message: 'Daily backup completed successfully'
    }
  } catch (error) {
    console.error('Daily backup failed:', error)
    return {
      status: 'failed',
      error: error.message
    }
  }
}

async function refreshGlobalCache(supabase: any) {
  console.log('Refreshing global cache...')
  
  try {
    // Get fresh hostel data
    const { data: hostels, error: hostelsError } = await supabase
      .from('hostels')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100)

    if (!hostelsError) {
      await supabase
        .from('cache_entries')
        .upsert({
          cache_key: 'all_hostels',
          data: hostels,
          expires_at: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString() // 2 hours
        })
    }

    // Get admin statistics
    const { data: stats, error: statsError } = await supabase
      .rpc('get_admin_stats')

    if (!statsError) {
      await supabase
        .from('cache_entries')
        .upsert({
          cache_key: 'admin_stats',
          data: stats,
          expires_at: new Date(Date.now() + 30 * 60 * 1000).toISOString() // 30 minutes
        })
    }

    // Clean up expired cache entries
    await supabase
      .from('cache_entries')
      .delete()
      .lt('expires_at', new Date().toISOString())

    return {
      status: 'completed',
      message: 'Cache refreshed successfully',
      entries_updated: ['all_hostels', 'admin_stats']
    }
  } catch (error) {
    console.error('Cache refresh failed:', error)
    return {
      status: 'failed',
      error: error.message
    }
  }
}

async function performSecurityAudit(supabase: any) {
  console.log('Performing security audit...')
  
  try {
    const auditResults = []

    // Check for suspicious login patterns
    const { data: suspiciousLogins, error: loginError } = await supabase
      .from('security_events')
      .select('*')
      .eq('event_type', 'suspicious_activity')
      .gte('timestamp', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())

    if (!loginError) {
      auditResults.push({
        check: 'suspicious_logins',
        count: suspiciousLogins.length,
        severity: suspiciousLogins.length > 10 ? 'high' : 'low'
      })
    }

    // Check for failed 2FA attempts
    const { data: failed2FA, error: twoFAError } = await supabase
      .from('security_events')
      .select('*')
      .eq('event_type', '2fa_failed')
      .gte('timestamp', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())

    if (!twoFAError) {
      auditResults.push({
        check: 'failed_2fa_attempts',
        count: failed2FA.length,
        severity: failed2FA.length > 5 ? 'medium' : 'low'
      })
    }

    // Check for rate limit breaches
    const { data: rateLimitBreaches, error: rateLimitError } = await supabase
      .from('security_events')
      .select('*')
      .eq('event_type', 'rate_limit_breach')
      .gte('timestamp', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())

    if (!rateLimitError) {
      auditResults.push({
        check: 'rate_limit_breaches',
        count: rateLimitBreaches.length,
        severity: rateLimitBreaches.length > 20 ? 'high' : 'low'
      })
    }

    // Save audit results
    await supabase
      .from('security_events')
      .insert({
        event_type: 'security_audit_completed',
        details: {
          audit_results: auditResults,
          timestamp: new Date().toISOString()
        }
      })

    return {
      status: 'completed',
      message: 'Security audit completed',
      results: auditResults
    }
  } catch (error) {
    console.error('Security audit failed:', error)
    return {
      status: 'failed',
      error: error.message
    }
  }
}

async function cleanupOldData(supabase: any) {
  console.log('Cleaning up old data...')
  
  try {
    const cutoffDate = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString() // 90 days ago

    // Clean old security events
    const { error: securityError } = await supabase
      .from('security_events')
      .delete()
      .lt('timestamp', cutoffDate)

    // Clean old login attempts
    const { error: loginError } = await supabase
      .from('login_attempts')
      .delete()
      .lt('attempt_time', cutoffDate)

    // Clean expired rate limits
    const { error: rateLimitError } = await supabase
      .from('rate_limits')
      .delete()
      .lt('first_request_time', cutoffDate)

    return {
      status: 'completed',
      message: 'Old data cleanup completed',
      cutoff_date: cutoffDate
    }
  } catch (error) {
    console.error('Data cleanup failed:', error)
    return {
      status: 'failed',
      error: error.message
    }
  }
}

async function generateDailyReports(supabase: any, parameters: any) {
  console.log('Generating daily reports...')
  
  try {
    const today = new Date()
    const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000)

    // Get daily statistics
    const { data: dailyStats, error: statsError } = await supabase
      .rpc('get_admin_stats')

    // Get new hostels added today
    const { data: newHostels, error: hostelsError } = await supabase
      .from('hostels')
      .select('*')
      .gte('created_at', yesterday.toISOString())

    // Get security events for today
    const { data: securityEvents, error: securityError } = await supabase
      .from('security_events')
      .select('event_type')
      .gte('timestamp', yesterday.toISOString())

    const report = {
      date: today.toISOString().split('T')[0],
      statistics: dailyStats,
      new_hostels: newHostels?.length || 0,
      security_events: securityEvents?.length || 0,
      generated_at: new Date().toISOString()
    }

    // Store the report
    await supabase
      .from('daily_reports')
      .insert(report)

    return {
      status: 'completed',
      message: 'Daily report generated',
      report
    }
  } catch (error) {
    console.error('Report generation failed:', error)
    return {
      status: 'failed',
      error: error.message
    }
  }
}

async function monitorPerformance(supabase: any) {
  console.log('Monitoring performance...')
  
  try {
    const performanceMetrics = {
      timestamp: new Date().toISOString(),
      database_connections: await getDatabaseConnections(supabase),
      cache_hit_ratio: await getCacheHitRatio(supabase),
      average_response_time: await getAverageResponseTime(supabase)
    }

    // Store performance metrics
    await supabase
      .from('performance_metrics')
      .insert(performanceMetrics)

    return {
      status: 'completed',
      message: 'Performance monitoring completed',
      metrics: performanceMetrics
    }
  } catch (error) {
    console.error('Performance monitoring failed:', error)
    return {
      status: 'failed',
      error: error.message
    }
  }
}

async function getDatabaseConnections(supabase: any) {
  // Placeholder for database connection monitoring
  return Math.floor(Math.random() * 100)
}

async function getCacheHitRatio(supabase: any) {
  // Placeholder for cache hit ratio calculation
  return 0.85 + Math.random() * 0.1
}

async function getAverageResponseTime(supabase: any) {
  // Placeholder for response time monitoring
  return 100 + Math.random() * 50
}